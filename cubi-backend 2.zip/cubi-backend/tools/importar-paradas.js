#!/usr/bin/env node
'use strict';
// Genera data/paradas.json con las paradas que usa la app ("Paradas cerca de ti").
//   node tools/importar-paradas.js osm                      -> descarga las paradas de OpenStreetMap (zona metropolitana de Puebla)
//   node tools/importar-paradas.js paraderos.csv mapa.geojson -> importa archivos (p. ej. "Paraderos RUTA" del Portal de Datos de Puebla)
const fs = require('fs'), path = require('path');
const OUT = path.join(__dirname, '..', 'data', 'paradas.json');
const BBOX = '18.90,-98.40,19.20,-98.00'; // sur, oeste, norte, este
const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
const num = v => Number(String(v).replace(',', '.').trim());

function csvRows(text) {
  const first = text.split(/\r?\n/)[0], sep = (first.match(/;/g) || []).length > (first.match(/,/g) || []).length ? ';' : ',';
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
    else if (c === '"') q = true;
    else if (c === sep) { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); rows.push(row); row = []; cur = ''; }
    else cur += c;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(x => x.trim()));
}
function fromCSV(text) {
  const rows = csvRows(text.replace(/^\uFEFF/, '')), head = rows.shift().map(norm), col = re => head.findIndex(h => re.test(h));
  const iLat = col(/^(lat|latitud|latitude|y)$/), iLng = col(/^(lon|lng|long|longitud|longitude|x)$/);
  const iName = col(/(nombre|paradero|parada|estacion|name|ubicacion)/), iRoute = col(/(ruta|linea|route)/), iDir = col(/sentido/);
  if (iLat < 0 || iLng < 0) throw new Error('No encontré columnas de latitud y longitud. Encabezados del archivo: ' + head.join(', '));
  return rows.map((r, i) => ({ n: (r[iName] || '').trim() || 'Parada ' + (i + 1), lat: num(r[iLat]), lng: num(r[iLng]), routes: iRoute >= 0 && r[iRoute] ? [r[iRoute].trim()] : [], dir: iDir >= 0 ? (r[iDir] || '').trim() : '' }));
}
function fromGeoJSON(text) {
  const g = JSON.parse(text), feats = g.type === 'FeatureCollection' ? g.features : [g];
  return feats.filter(f => f.geometry && f.geometry.type === 'Point').map((f, i) => {
    const p = f.properties || {}, nk = Object.keys(p).find(k => /(nombre|paradero|parada|estacion|name)/.test(norm(k)));
    return { n: String(p[nk] || 'Parada ' + (i + 1)), lat: f.geometry.coordinates[1], lng: f.geometry.coordinates[0], routes: [] };
  });
}
async function fromOSM() {
  const q = `[out:json][timeout:90];(node["highway"="bus_stop"](${BBOX});node["public_transport"="platform"]["bus"="yes"](${BBOX}););out;`;
  const r = await fetch('https://overpass-api.de/api/interpreter', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'data=' + encodeURIComponent(q) });
  if (!r.ok) throw new Error('Overpass respondió ' + r.status + '. Intenta de nuevo en unos minutos.');
  return (await r.json()).elements.map(e => ({ n: e.tags?.name || e.tags?.ref || 'Parada', lat: e.lat, lng: e.lon, routes: (e.tags?.route_ref || '').split(';').map(x => x.trim()).filter(Boolean) }));
}
function clean(list) { // descarta coordenadas inválidas o fuera de Puebla y elimina duplicados
  const seen = new Set(), out = [];
  for (const s of list) {
    if (!Number.isFinite(s.lat) || !Number.isFinite(s.lng) || s.lat < 17.8 || s.lat > 20.9 || s.lng < -99.1 || s.lng > -96.7) continue;
    const k = s.lat.toFixed(5) + ',' + s.lng.toFixed(5); if (seen.has(k)) continue; seen.add(k);
    out.push({ id: 's' + (out.length + 1), n: s.n, lat: +s.lat.toFixed(6), lng: +s.lng.toFixed(6), routes: s.routes || [], ...(s.dir ? { dir: s.dir } : {}) });
  }
  return out;
}
(async () => {
  const args = process.argv.slice(2);
  if (!args.length) { console.log('Uso: node tools/importar-paradas.js osm | archivo.csv archivo.geojson'); process.exit(1); }
  let all = [];
  for (const a of args) {
    if (a === 'osm') all = all.concat(await fromOSM());
    else { const t = fs.readFileSync(a, 'utf8'); all = all.concat(/\.(geo)?json$/i.test(a) ? fromGeoJSON(t) : fromCSV(t)); }
  }
  const out = clean(all);
  fs.mkdirSync(path.dirname(OUT), { recursive: true }); fs.writeFileSync(OUT, JSON.stringify(out));
  console.log(`Listo: ${out.length} paradas guardadas en ${OUT} (descartadas: ${all.length - out.length}). Reinicia el servidor para cargarlas.`);
})().catch(e => { console.error('Error:', e.message); process.exit(1); });
