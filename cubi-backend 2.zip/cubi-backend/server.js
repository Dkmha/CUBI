'use strict';
require('dotenv').config();
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const express = require('express'), cors = require('cors'), jwt = require('jsonwebtoken'), bcrypt = require('bcryptjs'), helmet = require('helmet');

const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || 'dev-secret-cambiame';
const OPKEY = process.env.OPERATOR_KEY || 'dev-operator-key';
const BONUS = Number(process.env.WELCOME_BONUS ?? 50);
if (process.env.NODE_ENV === 'production' && (SECRET === 'dev-secret-cambiame' || OPKEY === 'dev-operator-key')) {
  console.error('Define JWT_SECRET y OPERATOR_KEY en producción'); process.exit(1);
}

// ---- Datos: directorio de rutas (solo lectura) y una base JSON sencilla ----
const DATA = path.join(__dirname, 'data'), FILE = process.env.DB_FILE || path.join(DATA, 'db.json');
const ROUTES = JSON.parse(fs.readFileSync(path.join(DATA, 'rutas.json'), 'utf8'));
const db = fs.existsSync(FILE) ? JSON.parse(fs.readFileSync(FILE, 'utf8')) : { users: [], payments: [], reports: [], verifs: [] };
db.verifs = db.verifs || []; db.subs = db.subs || []; db.sponsors = db.sponsors || []; db.fleets = db.fleets || []; db.stops = db.stops || []; db.stopSuggestions = db.stopSuggestions || []; db.passes = db.passes || [];
const save = () => { fs.writeFileSync(FILE + '.tmp', JSON.stringify(db)); fs.renameSync(FILE + '.tmp', FILE); };
const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
// Tarifas de referencia de Puebla (octubre de 2026). Actualiza esta tabla si cambia la tarifa oficial.
const FARES = { autobus: { gen: 8.5, est: 6, mayor: 4, nino: 0, disc: 0 }, combi: { gen: 8, est: 6, mayor: 4, nino: 0, disc: 0 },
  ruta: { gen: 7.5, est: null, mayor: 4.5, nino: null, disc: 0 } }; // RUTA líneas 1-3: sin descuento de estudiante ni de niños según las fuentes consultadas (null = no aplica)
const METHODS = ['saldo', 'card', 'cash', 'gratis', 'pase'], VKINDS = ['est', 'mayor', 'disc']; // est/mayor/disc requieren verificación
const cents = n => Math.round(n * 100) / 100;
const COMMISSION = Number(process.env.COMMISSION ?? 0.02); // comisión sobre pagos digitales, se cobra a la concesionaria
const verified = (uid, kind) => db.verifs.some(v => v.user === uid && v.kind === kind && v.status === 'ok' && new Date(v.until + 'T23:59:59') >= new Date());
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });

const app = express();
app.disable('x-powered-by');
if (process.env.TRUST_PROXY) app.set('trust proxy', process.env.TRUST_PROXY === 'true' ? 1 : process.env.TRUST_PROXY);
app.use(helmet());
app.use((req, res, next) => { // registro de peticiones (sin parámetros de búsqueda)
  const t = Date.now();
  res.on('finish', () => { if (process.env.NODE_ENV !== 'test') console.log(`${req.method} ${req.originalUrl.split('?')[0]} ${res.statusCode} ${Date.now() - t}ms`); });
  next();
});
app.use(cors({ origin: (process.env.CORS_ORIGIN || 'http://127.0.0.1:5500,http://localhost:5500').split(',') }));
app.use(express.json({ limit: '100kb' }));

// Límite simple de intentos por IP (para producción usa express-rate-limit o un proxy)
const hits = new Map();
setInterval(() => { const n = Date.now(); for (const [k, a] of hits) if (!a.some(t => n - t < 15 * 60e3)) hits.delete(k); }, 5 * 60e3).unref();
const limit = (max, ms) => (req, res, next) => {
  const k = req.ip + req.path, now = Date.now(), a = (hits.get(k) || []).filter(t => now - t < ms);
  if (a.length >= max) return bad(res, 'Demasiados intentos. Intenta más tarde.', 429);
  a.push(now); hits.set(k, a); next();
};
const sign = u => jwt.sign({ sub: u.id, tv: u.tv || 0 }, SECRET, { expiresIn: '7d' });
const auth = (req, res, next) => {
  try {
    const { sub, tv } = jwt.verify((req.headers.authorization || '').replace(/^Bearer /, ''), SECRET);
    req.user = db.users.find(u => u.id === sub); if (!req.user || (req.user.tv || 0) !== (tv || 0)) throw 0; next();
  } catch { bad(res, 'No autorizado', 401); }
};
const operator = (req, res, next) => req.headers['x-operator-key'] === OPKEY ? next() : bad(res, 'Clave de operador inválida', 401);
const okEmail = e => typeof e === 'string' && /^\S+@\S+\.\S+$/.test(e);

// ---- Autenticación ----
app.post('/auth/register', limit(10, 15 * 60e3), async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !String(name).trim()) return bad(res, 'Escribe tu nombre.');
  if (!okEmail(email)) return bad(res, 'Escribe un correo válido.');
  if (typeof password !== 'string' || password.length < 6) return bad(res, 'La contraseña debe tener al menos 6 caracteres.');
  const mail = email.trim().toLowerCase();
  if (db.users.some(u => u.email === mail)) return bad(res, 'Ese correo ya tiene una cuenta.', 409);
  const u = { id: crypto.randomUUID(), name: String(name).trim().slice(0, 60), email: mail, hash: await bcrypt.hash(password, 10), wallet: BONUS, created: new Date().toISOString() };
  db.users.push(u); save(); res.status(201).json({ name: u.name, token: sign(u) });
});
app.post('/auth/login', limit(10, 15 * 60e3), async (req, res) => {
  const { email, password } = req.body || {};
  const u = okEmail(email) && db.users.find(x => x.email === email.trim().toLowerCase());
  if (!u || typeof password !== 'string' || !(await bcrypt.compare(password, u.hash))) return bad(res, 'Correo o contraseña incorrectos.', 401);
  res.json({ name: u.name, token: sign(u) });
});
app.get('/me', auth, (req, res) => { const had = !!req.user.ref; const ref = refOf(req.user); if (!had) save(); res.json({ name: req.user.name, email: req.user.email, wallet: req.user.wallet, plus: plusInfo(req.user.id), ref, referrals: req.user.referrals || 0, pass: passInfo(activePass(req.user.id)) }); });

// ---- Directorio de rutas ----
app.get('/routes', (req, res) => {
  const q = norm(req.query.q).trim();
  const out = ROUTES.filter(r => !q || norm([r.n, r.k, ...r.t.flatMap(t => [t.a, t.z, ...t.p.map(x => x[1])])].join(' ')).includes(q))
    .slice(0, 50).map(r => ({ id: r.i, name: r.n, clave: r.k, tramos: r.t.length }));
  res.json(out);
});
app.get('/routes/:id', (req, res) => {
  const r = ROUTES.find(x => x.i === Number(req.params.id));
  r ? res.json(r) : bad(res, 'Ruta no encontrada', 404);
});

// ---- Estado de las unidades: simulado hasta que lleguen datos reales de GPS ----
const live = new Map(), lvl = o => o < 40 ? 'Bajo' : o < 75 ? 'Medio' : 'Alto';
const status = id => {
  const now = Date.now();
  let s = live.get(id);
  if (!s) { s = { occ: 30 + (id * 13) % 50, cap: 30, arr: 2 + id % 8, base: 2 + id % 8, ts: now, real: false }; live.set(id, s); }
  if (s.real && now - s.ts > 60e3) s.real = false; // telemetría vencida: vuelve a simular
  if (!s.real && now - s.ts > 8e3) { s.ts = now; s.arr = s.arr > 1 ? s.arr - 1 : s.base; s.occ = Math.max(10, Math.min(95, s.occ + (Math.random() < .5 ? -4 : 4))); }
  return { arr: s.arr, occ: s.occ, seats: Math.round(s.cap * (1 - s.occ / 100)), lvl: lvl(s.occ), real: s.real, lat: s.lat, lng: s.lng };
};
// Recorrido con coordenadas de una ruta del directorio: data/rutas_geo.json = { "<id>": [ [[lat,lng],...], ... ] } (opcional)
const GEO_FILE = process.env.GEO_FILE || path.join(DATA, 'rutas_geo.json');
const geo = fs.existsSync(GEO_FILE) ? JSON.parse(fs.readFileSync(GEO_FILE, 'utf8')) : {};
app.get('/routes/:id/geo', (req, res) => geo[req.params.id] ? res.json(geo[req.params.id]) : bad(res, 'Esta ruta aún no tiene recorrido con coordenadas.', 404));
app.get('/routes/:id/status', (req, res) => {
  const id = Number(req.params.id);
  Number.isInteger(id) && ROUTES.some(r => r.i === id) ? res.json(status(id)) : bad(res, 'Ruta no encontrada', 404);
});
// Las unidades (o su app de conductor) envían aquí posición y ocupación reales
app.post('/units/:route/telemetry', operator, (req, res) => {
  const id = Number(req.params.route), b = req.body || {};
  if (!ROUTES.some(r => r.i === id)) return bad(res, 'Ruta no encontrada', 404);
  const ranges = { occ: [0, 100], cap: [1, 200], arr: [0, 120], lat: [-90, 90], lng: [-180, 180] };
  for (const [k, [lo, hi]] of Object.entries(ranges)) if (b[k] !== undefined && !(Number.isFinite(b[k]) && b[k] >= lo && b[k] <= hi)) return bad(res, `Valor inválido en ${k}.`);
  status(id); const s = live.get(id);
  for (const k of Object.keys(ranges)) if (b[k] !== undefined) s[k] = b[k];
  Object.assign(s, { real: true, ts: Date.now() });
  res.json(status(id));
});

// ---- Saldo, pagos y reportes ----
app.post('/wallet/topup', auth, (req, res) => {
  const a = Number(req.body?.amount);
  if (![20, 50, 100, 200, 500].includes(a)) return bad(res, 'Monto no permitido.');
  req.user.wallet += a; save(); res.json({ wallet: req.user.wallet }); // En producción, esto va después de confirmar el cobro con tu pasarela de pago
});
app.post('/payments', auth, (req, res) => {
  const { route, kind, fare, method, amount } = req.body || {};
  if (!ROUTES.some(r => r.i === Number(route))) return bad(res, 'Ruta no encontrada', 404);
  if (!FARES[kind] || !(fare in FARES[kind]) || !METHODS.includes(method)) return bad(res, 'Datos de pago inválidos.');
  if (VKINDS.includes(fare) && !verified(req.user.id, fare)) return bad(res, 'Tu tarifa preferencial no está verificada o ya venció.', 403);
  const price = FARES[kind][fare];
  if (price === null) return bad(res, 'Esa tarifa no aplica a este servicio.');
  if (amount !== undefined && Number(amount) !== price) return bad(res, 'La tarifa no coincide.', 409);
  if (price > 0 && method === 'gratis') return bad(res, 'Este pasaje no es gratuito.');
  if (price > 0 && method === 'pase') { const ps = activePass(req.user.id); if (!ps) return bad(res, 'No tienes un pase activo con viajes disponibles.', 402); ps.left--; }
  if (price > 0 && method === 'saldo') { if (req.user.wallet < price) return bad(res, 'Saldo insuficiente.', 402); req.user.wallet = cents(req.user.wallet - price); }
  // La comisión de los viajes pagados con pase ya se cobró al vender el pase.
  const p = { folio: crypto.randomInt(100000, 1000000), user: req.user.id, route: Number(route), kind, fare, method: price ? method : 'gratis', amount: price, fee: method === 'pase' ? 0 : cents(price * COMMISSION), at: new Date().toISOString() };
  db.payments.push(p); save(); res.status(201).json({ folio: p.folio, wallet: req.user.wallet });
});
// ---- Verificación de tarifas preferenciales (estudiante, adulto mayor, discapacidad) ----
// Hoy solo guarda los datos y el estado. Las fotos de credenciales requieren almacenamiento seguro antes de producción.
app.post('/verifications', auth, (req, res) => {
  const { kind, name, org, folio, until, hasDoc } = req.body || {};
  if (!VKINDS.includes(kind)) return bad(res, 'Tipo de tarifa inválido.');
  if (typeof name !== 'string' || name.trim().length < 3) return bad(res, 'Escribe tu nombre completo.');
  if (typeof folio !== 'string' || folio.trim().length < 4) return bad(res, 'Escribe el folio de tu credencial.');
  if (kind === 'est' && !(typeof org === 'string' && org.trim())) return bad(res, 'Escribe el nombre de tu escuela.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(until || '') || new Date(until + 'T23:59:59') < new Date()) return bad(res, 'La vigencia debe ser una fecha futura.');
  if (hasDoc !== true) return bad(res, 'Adjunta una foto de tu credencial.');
  db.verifs = db.verifs.filter(v => !(v.user === req.user.id && v.kind === kind));
  const v = { id: crypto.randomUUID(), user: req.user.id, kind, name: name.trim().slice(0, 80), org: String(org || '').trim().slice(0, 80), folio: '••••' + folio.trim().slice(-3), until, status: 'pending', at: new Date().toISOString() };
  db.verifs.push(v); save(); res.status(201).json({ id: v.id, status: v.status });
});
app.get('/me/verifications', auth, (req, res) => res.json(db.verifs.filter(v => v.user === req.user.id).map(({ user, ...v }) => v)));
app.get('/verifications', operator, (req, res) => res.json(db.verifs.filter(v => !req.query.status || v.status === req.query.status)));
app.patch('/verifications/:id', operator, (req, res) => {
  const v = db.verifs.find(x => x.id === req.params.id), { status, note } = req.body || {};
  if (!v) return bad(res, 'Solicitud no encontrada', 404);
  if (!['ok', 'rejected'].includes(status)) return bad(res, "El estado debe ser 'ok' o 'rejected'.");
  Object.assign(v, { status, note: String(note || '').slice(0, 200), reviewed: new Date().toISOString() }); save(); res.json(v);
});
app.get('/me/trips', auth, (req, res) => res.json(db.payments.filter(p => p.user === req.user.id).reverse().slice(0, 100)));
app.post('/reports', auth, (req, res) => {
  const { route, reason, hasPhoto } = req.body || {};
  if (!ROUTES.some(r => r.i === Number(route)) || !reason) return bad(res, 'Datos del reporte incompletos.');
  const r = { id: crypto.randomUUID(), user: req.user.id, route: Number(route), reason: String(reason).slice(0, 120), hasPhoto: !!hasPhoto, at: new Date().toISOString() };
  db.reports.push(r); save(); res.status(201).json({ id: r.id });
});
app.get('/reports', operator, (req, res) => res.json(db.reports.slice(-200).reverse())); // para el panel de empresas

app.post('/auth/password', auth, limit(10, 15 * 60e3), async (req, res) => {
  const { current, next } = req.body || {};
  if (typeof next !== 'string' || next.length < 6) return bad(res, 'La nueva contraseña debe tener al menos 6 caracteres.');
  if (typeof current !== 'string' || !(await bcrypt.compare(current, req.user.hash))) return bad(res, 'La contraseña actual es incorrecta.', 403);
  req.user.hash = await bcrypt.hash(next, 10); req.user.tv = (req.user.tv || 0) + 1; save(); res.json({ ok: true, token: sign(req.user) }); // invalida las sesiones anteriores
});
app.delete('/me', auth, (req, res) => { // elimina la cuenta y sus datos
  const id = req.user.id;
  db.users = db.users.filter(u => u.id !== id); db.payments = db.payments.filter(p => p.user !== id); db.reports = db.reports.filter(r => r.user !== id); db.verifs = db.verifs.filter(v => v.user !== id); db.subs = db.subs.filter(x => x.user !== id); db.passes = db.passes.filter(x => x.user !== id);
  save(); res.json({ ok: true });
});

// ---- Ingresos: Cubi Plus, patrocinios, flotas y comisión ----
// Precios y comisión son hipótesis para validar. Aquí se conecta la pasarela de pago (Stripe, Mercado Pago…) antes de cobrar de verdad.
const PLUS = { month: 29, year: 249, student: 19 }, TRIAL_DAYS = 7; // student: requiere tarifa de estudiante verificada
const latestSub = uid => db.subs.filter(v => v.user === uid).sort((a, b) => new Date(a.until) - new Date(b.until)).pop();
function plusInfo(uid) {
  const x = latestSub(uid);
  return x && new Date(x.until) > new Date() ? { plan: x.plan, until: x.until, trial: x.trial, cancelled: !!x.cancelled } : null;
}
app.post('/me/plus', auth, (req, res) => {
  const plan = req.body?.plan;
  if (!(plan in PLUS)) return bad(res, 'Plan inválido.');
  if (plan === 'student' && !verified(req.user.id, 'est')) return bad(res, 'El plan Estudiante requiere tu tarifa de estudiante verificada.', 403);
  if (plusInfo(req.user.id)) return bad(res, 'Ya tienes Cubi Plus activo.', 409);
  const trial = !db.subs.some(v => v.user === req.user.id); // la prueba gratis se usa una sola vez
  const until = new Date(Date.now() + (trial ? TRIAL_DAYS : plan === 'year' ? 365 : 30) * 864e5).toISOString();
  db.subs.push({ id: crypto.randomUUID(), user: req.user.id, plan, price: PLUS[plan], trial, since: new Date().toISOString(), until }); save();
  res.status(201).json({ plan, until, trial, note: 'Modo demo: no se realiza ningún cobro.' });
});
app.delete('/me/plus', auth, (req, res) => {
  const x = latestSub(req.user.id);
  if (!x || !plusInfo(req.user.id)) return bad(res, 'No tienes una suscripción activa.', 404);
  x.cancelled = true; save(); res.json({ ok: true, until: x.until }); // conserva beneficios hasta el fin del periodo
});
app.get('/sponsors', (req, res) => res.json(db.sponsors.filter(v => v.active).map(({ views, clicks, monthly, redeemed, perk, ...v }) => ({ ...v, perk: perk ? { text: perk.text } : undefined }))));
app.post('/sponsors', operator, (req, res) => {
  const { name, text, cta, url, monthly, perk } = req.body || {};
  if (!name || !text || !/^https?:\/\//.test(url || '')) return bad(res, 'Faltan nombre, texto o una URL http(s) válida.');
  const v = { id: crypto.randomUUID(), n: String(name).slice(0, 60), t: String(text).slice(0, 140), cta: String(cta || 'Ver más').slice(0, 24), url, monthly: Number(monthly) || 0, perk: perk && perk.text && perk.code ? { text: String(perk.text).slice(0, 80), code: String(perk.code).slice(0, 24) } : undefined, active: true, views: 0, clicks: 0, redeemed: 0 };
  db.sponsors.push(v); save(); res.status(201).json(v);
});
app.post('/sponsors/:id/event', limit(120, 60e3), (req, res) => {
  const v = db.sponsors.find(x => x.id === req.params.id), t = req.body?.type;
  if (!v || !['view', 'click'].includes(t)) return bad(res, 'Evento inválido.', 404);
  v[t === 'view' ? 'views' : 'clicks']++; save(); res.json({ ok: true });
});
app.post('/fleets', operator, (req, res) => { // contrato de una concesionaria: unidades x precio mensual
  const { name, units, pricePerUnit } = req.body || {};
  if (!name || !(units > 0) || !(pricePerUnit > 0)) return bad(res, 'Faltan nombre, unidades o precio por unidad.');
  const f = { id: crypto.randomUUID(), name: String(name).slice(0, 80), units: Math.floor(units), pricePerUnit: Number(pricePerUnit), active: true, since: new Date().toISOString() };
  db.fleets.push(f); save(); res.status(201).json(f);
});
app.get('/admin/revenue', operator, (req, res) => { // ingresos reales del mes para tu tablero
  const now = new Date(), month = now.toISOString().slice(0, 7), live = db.subs.filter(v => new Date(v.until) > now);
  const pay = db.payments.filter(p => p.at.startsWith(month) && p.method !== 'pase'), ps = db.passes.filter(p => p.at.startsWith(month)), volume = cents(pay.reduce((a, p) => a + p.amount, 0)), fees = cents(pay.reduce((a, p) => a + (p.fee || 0), 0));
  const mrrPlus = cents(live.filter(v => !v.trial && !v.reward).reduce((a, v) => a + (v.plan === 'year' ? v.price / 12 : v.price), 0));
  const fl = db.fleets.filter(f => f.active), mrrFleet = cents(fl.reduce((a, f) => a + f.units * f.pricePerUnit, 0));
  const sp = db.sponsors.filter(v => v.active), mrrSp = cents(sp.reduce((a, v) => a + v.monthly, 0));
  res.json({ month, fleet: { contracts: fl.length, units: fl.reduce((a, f) => a + f.units, 0), mrr: mrrFleet }, plus: { paying: live.filter(v => !v.trial && !v.reward).length, trials: live.filter(v => v.trial).length, mrr: mrrPlus },
    payments: { count: pay.length, volume, commissionRate: COMMISSION, fees }, sponsors: { active: sp.length, views: sp.reduce((a, v) => a + v.views, 0), clicks: sp.reduce((a, v) => a + v.clicks, 0), redeemed: sp.reduce((a, v) => a + (v.redeemed || 0), 0), mrr: mrrSp }, passes: { sold: ps.length, volume: cents(ps.reduce((a, p) => a + p.price, 0)), fees: cents(ps.reduce((a, p) => a + p.fee, 0)) }, totalMonthly: cents(mrrFleet + mrrPlus + mrrSp + fees + ps.reduce((a, p) => a + p.fee, 0)) });
});

// ---- Beneficios de comercios (solo Plus) y referidos ----
const refOf = u => (u.ref ||= 'CUBI-' + crypto.randomBytes(3).toString('hex').toUpperCase());
app.get('/perks', auth, (req, res) => {
  if (!plusInfo(req.user.id)) return bad(res, 'Los beneficios son parte de Cubi Plus.', 403);
  res.json(db.sponsors.filter(v => v.active && v.perk).map(v => ({ id: v.id, n: v.n, t: v.perk.text, code: v.perk.code })));
});
app.post('/perks/:id/redeem', auth, (req, res) => {
  if (!plusInfo(req.user.id)) return bad(res, 'Los beneficios son parte de Cubi Plus.', 403);
  const v = db.sponsors.find(x => x.id === req.params.id && x.perk);
  if (!v) return bad(res, 'Beneficio no encontrado', 404);
  v.redeemed = (v.redeemed || 0) + 1; save(); res.json({ ok: true });
});
function grantReward(uid) { // +7 días de Plus que se suman a lo que ya tenga
  const cur = plusInfo(uid), base = cur ? new Date(cur.until) : new Date();
  db.subs.push({ id: crypto.randomUUID(), user: uid, plan: cur ? cur.plan : 'month', price: 0, trial: false, reward: true, cancelled: cur ? !!cur.cancelled : true, since: new Date().toISOString(), until: new Date(base.getTime() + 7 * 864e5).toISOString() });
}
app.post('/referrals/redeem', auth, (req, res) => {
  const code = String(req.body?.code || '').trim().toUpperCase();
  if (req.user.refBy) return bad(res, 'Ya canjeaste un código.', 409);
  const owner = db.users.find(u => u.ref === code);
  if (!owner || owner.id === req.user.id) return bad(res, 'Código inválido.', 404);
  req.user.refBy = owner.id; owner.referrals = (owner.referrals || 0) + 1;
  grantReward(req.user.id); grantReward(owner.id); save();
  res.json({ ok: true, plus: plusInfo(req.user.id) });
});

// ---- Pase Cubi: viajes prepagados por 30 días ----
// Precio de lista (viajes x $8.50, sin descuento). Cubi cobra la comisión al venderlo; el bono de viajes es para Plus.
const PASSES = { p20: { n: 20, price: 170, bonus: 0 }, p40: { n: 40, price: 340, bonus: 2 }, p60: { n: 60, price: 510, bonus: 4 } };
const activePass = uid => db.passes.filter(p => p.user === uid && p.left > 0 && new Date(p.until) > new Date()).pop();
const passInfo = p => (p ? { pack: p.pack, total: p.total, left: p.left, until: p.until } : null);
app.post('/passes', auth, (req, res) => {
  const { pack, method } = req.body || {}, x = PASSES[pack];
  if (!x || !['saldo', 'card'].includes(method)) return bad(res, 'Datos de compra inválidos.');
  if (activePass(req.user.id)) return bad(res, 'Ya tienes un pase activo.', 409);
  if (method === 'saldo') { if (req.user.wallet < x.price) return bad(res, 'Saldo insuficiente.', 402); req.user.wallet = cents(req.user.wallet - x.price); }
  const total = x.n + (plusInfo(req.user.id) ? x.bonus : 0); // en producción, la tarjeta se cobra con tu pasarela antes de este punto
  const p = { id: crypto.randomUUID(), user: req.user.id, pack, total, left: total, price: x.price, fee: cents(x.price * COMMISSION), method, at: new Date().toISOString(), until: new Date(Date.now() + 30 * 864e5).toISOString() };
  db.passes.push(p); save(); res.status(201).json({ ...passInfo(p), wallet: req.user.wallet });
});
app.get('/me/pass', auth, (req, res) => res.json(passInfo(activePass(req.user.id))));

// ---- Paradas: archivo data/paradas.json (opcional) + paradas sugeridas por la comunidad ----
const STOPS_FILE = process.env.STOPS_FILE || path.join(DATA, 'paradas.json'); // [{ id, n, lat, lng, routes: [] }], se genera con tools/importar-paradas.js
const baseStops = fs.existsSync(STOPS_FILE) ? JSON.parse(fs.readFileSync(STOPS_FILE, 'utf8')) : [];
const hav = (a, b, c, d) => { const r = x => x * Math.PI / 180, dl = r(c - a), dn = r(d - b), x = Math.sin(dl / 2) ** 2 + Math.cos(r(a)) * Math.cos(r(c)) * Math.sin(dn / 2) ** 2; return 2 * 6371e3 * Math.asin(Math.sqrt(x)); };
const okCoord = (lat, lng) => Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180;
app.get('/stops', (req, res) => {
  const lat = Number(req.query.lat), lng = Number(req.query.lng), r = Math.min(Number(req.query.r) || 1500, 5000);
  if (req.query.lat === undefined || !okCoord(lat, lng)) return bad(res, 'Envía lat y lng válidos.');
  res.json([...baseStops, ...db.stops].map(s => ({ ...s, d: Math.round(hav(lat, lng, s.lat, s.lng)) })).filter(s => s.d <= r).sort((a, b) => a.d - b.d).slice(0, 30));
});
app.post('/stops/suggest', auth, limit(20, 60 * 60e3), (req, res) => {
  const { name, lat, lng } = req.body || {};
  if (typeof name !== 'string' || name.trim().length < 3) return bad(res, 'Escribe el nombre o referencia de la parada.');
  if (!okCoord(lat, lng)) return bad(res, 'Ubicación inválida.');
  const v = { id: crypto.randomUUID(), user: req.user.id, name: name.trim().slice(0, 80), lat, lng, status: 'pending', at: new Date().toISOString() };
  db.stopSuggestions.push(v); save(); res.status(201).json({ id: v.id });
});
app.get('/stops/suggestions', operator, (req, res) => res.json(db.stopSuggestions.filter(v => !req.query.status || v.status === req.query.status)));
app.patch('/stops/suggestions/:id', operator, (req, res) => {
  const v = db.stopSuggestions.find(x => x.id === req.params.id), { status, routes } = req.body || {};
  if (!v) return bad(res, 'Sugerencia no encontrada', 404);
  if (!['ok', 'rejected'].includes(status)) return bad(res, "El estado debe ser 'ok' o 'rejected'.");
  v.status = status;
  if (status === 'ok') db.stops.push({ id: 'c' + v.id.slice(0, 8), n: v.name, lat: v.lat, lng: v.lng, routes: Array.isArray(routes) ? routes.slice(0, 10).map(String) : [], src: 'comunidad' });
  save(); res.json(v);
});

app.get('/health', (req, res) => res.json({ ok: true, routes: ROUTES.length }));
app.use((req, res) => bad(res, 'No encontrado', 404));
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return bad(res, 'JSON inválido.');
  console.error(err); bad(res, 'Error del servidor', 500);
});
if (require.main === module) {
  const srv = app.listen(PORT, () => console.log(`Cubi API en http://localhost:${PORT}`));
  for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => srv.close(() => process.exit(0)));
}
module.exports = { app };
