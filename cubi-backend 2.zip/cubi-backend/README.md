# Cubi · Backend

API en Node.js + Express. Guarda usuarios, pagos y reportes en `data/db.json` (suficiente para desarrollo; en producción pasa a PostgreSQL o MongoDB).

## Arrancar
1. `npm install`
2. Copia `.env.example` a `.env` y cambia `JWT_SECRET` y `OPERATOR_KEY`
3. `npm run dev` → http://localhost:3000/health

## Conectar la app
En el HTML de Cubi cambia `const API_URL='';` por `const API_URL='http://localhost:3000';` y ábrelo con Live Server (puerto 5500, ya permitido en CORS).

## Endpoints
| Método | Ruta | Descripción |
|---|---|---|
| POST | /auth/register, /auth/login | Devuelven `{name, token}` |
| GET | /me | Nombre, correo y saldo (token) |
| GET | /routes?q= · /routes/:id | Directorio de las 94 rutas |
| GET | /routes/:id/geo | Recorrido con coordenadas (si existe en `data/rutas_geo.json`) |
| GET | /routes/:id/status | Llegada, ocupación y asientos |
| POST | /units/:route/telemetry | Posición y ocupación reales (cabecera `x-operator-key`) |
| POST | /wallet/topup | Recarga de saldo (token) |
| POST | /payments | Cobra un pasaje `{route, kind: autobus\|combi, fare: gen\|est\|mayor\|nino\|disc, method}`; el precio lo define el servidor con las tarifas de Puebla; est/mayor/disc exigen verificación (token) |
| POST/GET | /verifications, /me/verifications | Enviar y consultar la verificación de tarifa preferencial (token) |
| GET/PATCH | /verifications, /verifications/:id | Revisar solicitudes: aprobar `ok` o rechazar `rejected` (operador) |
| POST | /auth/password | Cambia la contraseña (token) |
| DELETE | /me | Elimina la cuenta y sus datos (token) |
| POST/DELETE | /me/plus | Inicia (prueba de 7 días) o cancela Cubi Plus (token) |
| GET | /sponsors | Patrocinios activos para la app (con el texto del beneficio, sin el código) |
| GET | /perks · POST /perks/:id/redeem | Códigos de beneficios y su canje; solo Plus (token) |
| POST | /referrals/redeem | Canjea un código de invitación: +7 días de Plus para ambos (token) |
| POST | /sponsors, /fleets | Dar de alta un patrocinador o un contrato de flota (operador) |
| POST | /sponsors/:id/event | Registra vistas y clics (para reportar a anunciantes) |
| GET | /admin/revenue | Ingresos reales del mes por fuente (operador) |
| POST/GET | /passes, /me/pass | Compra del Pase Cubi (20/40/60 viajes, 30 días) y consulta del pase activo (token) |
| GET | /stops?lat=&lng=&r= | Paradas cercanas ordenadas por distancia |
| POST | /stops/suggest | El usuario sugiere una parada con su ubicación (token) |
| GET/PATCH | /stops/suggestions | Revisar y aprobar sugerencias; al aprobar se agrega la parada (operador) |
| GET | /me/trips | Historial de pagos (token) |
| POST/GET | /reports | Crear reporte (token) / listar para el panel (operador) |

## Pendiente antes de producción
- Cobros reales con una pasarela (Stripe, Mercado Pago…): hoy la recarga y las tarjetas son simuladas.
- Base de datos real, HTTPS, límite de peticiones robusto y copia de seguridad.
- Subida de fotos de reportes (hoy solo se guarda si había foto).
- Paradas con coordenadas: cuando las tengas, se agregan a `/routes/:id` y al mapa.

## Pruebas
`npm test` ejecuta 12 pruebas automáticas (registro, rutas, telemetría, pagos, reportes y cuenta) con una base temporal.

## Seguridad incluida
- Contraseñas con bcrypt; sesión con JWT de 7 días. Al cambiar la contraseña se invalidan las sesiones anteriores.
- Cabeceras de seguridad (helmet), CORS por lista de orígenes y límite de intentos en acceso y registro.
- El precio de los pasajes y los montos de recarga los define el servidor, no la app.
- Detrás de un proxy (Render, Railway, Nginx) define `TRUST_PROXY=true` para que el límite use la IP real.

## Tarifas
RUTA (líneas 1, 2 y 3): $7.50, adultos mayores $4.50 y discapacidad gratis; sin descuento de estudiante ni de niños según las fuentes consultadas (referencia de 2026). Tabla `FARES` en `server.js` (autobús $8.50, combi $8, estudiante $6, adulto mayor $4, discapacidad y niños menores de 5 años gratis; referencia octubre de 2026). Se prevé un ajuste de tarifa en Puebla: actualiza la tabla cuando se publique oficialmente. Las fotos de credenciales aún no se guardan: se necesita almacenamiento seguro antes de producción.

## Modelo de ingresos
1. **Flota (principal, recurrente):** suscripción por unidad al mes para concesionarias (panel, ocupación en vivo, reportes y cobro digital). Se registra con `POST /fleets`.
2. **Cubi Plus (usuarios):** $29/mes, $249/año o $19/mes con credencial de estudiante verificada; 7 días de prueba. Incluye contactos ilimitados, historial completo, resumen y presupuesto mensual, recarga automática, trayectos ilimitados, beneficios de comercios y paletas. Lo esencial sigue gratis. Invitar a un amigo da 7 días a ambos.
3. **Comisión por pagos digitales:** `COMMISSION` (2% por defecto) se cobra a la concesionaria, no al pasajero.
4. **Pase Cubi (prepago):** 20, 40 o 60 viajes por 30 días a precio de lista ($170, $340 y $510; viajes x $8.50). Cubi cobra la comisión (2%) al venderlo y el dinero prepagado entra de golpe; los miembros Plus reciben +2 o +4 viajes de bono. Un descuento real requiere acordarlo con las concesionarias.
5. **Patrocinios locales:** una tarjeta discreta marcada "Patrocinado"; se oculta con Plus. Mide vistas y clics.

`GET /admin/revenue` resume el mes. Los precios son hipótesis a validar. Cobrar de verdad exige conectar una pasarela de pago en `/me/plus` y `/wallet/topup`.

## Mapa y paradas con coordenadas
**Ya incluido:** `data/paradas.json` con 691 paradas (590 paraderos con marquesina del levantamiento de 2018 y las estaciones de las líneas 1, 2 y 3 de RUTA), generado así:
`node tools/importar-paradas.js Paraderos_RUTA.csv Paraderos.csv`
Falta la línea 4 (FINSA–Valsequillo) y las rutas convencionales. Para agregar más archivos, vuelve a correr el importador con todos juntos.

La app ya tiene "Paradas cerca de ti" y el backend sirve `GET /stops`. Solo falta cargar las paradas:
1. **RUTA (metrobús):** el Portal de Datos del Ayuntamiento de Puebla (datos.pueblacapital.gob.mx) publica "Paraderos RUTA" en CSV y "Líneas Ruta" en GeoJSON. Cubren solo las líneas troncales de RUTA.
2. **Rutas convencionales:** datos.gob.mx tiene "Rutas de Transporte Público" (JSON, Ayuntamiento de Puebla, zona conurbada), pero es un archivo antiguo. Para datos actuales, pide por transparencia a la Secretaría de Movilidad e Infraestructura un GTFS o KML de rutas y paradas.
3. **OpenStreetMap:** `node tools/importar-paradas.js osm` descarga las paradas que ya estén mapeadas. No se verificó qué tan completa es la cobertura en Puebla.
4. **Archivos descargados:** `node tools/importar-paradas.js paraderos.csv mapa.geojson` detecta columnas de latitud/longitud y nombre. Si las coordenadas vienen en UTM, conviértelas a latitud/longitud antes.
5. **Comunidad:** los usuarios sugieren paradas desde la app; apruebas con `PATCH /stops/suggestions/:id`.
