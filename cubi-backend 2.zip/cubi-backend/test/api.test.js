process.env.NODE_ENV = 'test';
process.env.DB_FILE = require('path').join(require('os').tmpdir(), `cubi-test-${process.pid}.json`);
process.env.WELCOME_BONUS = '50';
process.env.GEO_FILE = require('path').join(require('os').tmpdir(), 'geo-' + process.pid + '.json');
require('fs').writeFileSync(process.env.GEO_FILE, JSON.stringify({ 4: [[[19.04, -98.2], [19.05, -98.19]]] }));
process.env.STOPS_FILE = require('path').join(require('os').tmpdir(), 'sin-paradas-' + process.pid + '.json'); // las pruebas no usan el archivo real
const test = require('node:test'), assert = require('node:assert/strict'), fs = require('fs');
const { app } = require('../server');
let srv, base, tok;
const api = async (p, o = {}, t) => {
  const r = await fetch(base + p, { ...o, headers: { 'Content-Type': 'application/json', ...(t && { Authorization: 'Bearer ' + t }), ...(o.headers || {}) }, body: o.body && JSON.stringify(o.body) });
  return { s: r.status, j: await r.json().catch(() => null) };
};
test.before(() => new Promise(r => { srv = app.listen(0, () => { base = 'http://127.0.0.1:' + srv.address().port; r(); }); }));
test.after(() => { srv.close(); try { fs.unlinkSync(process.env.DB_FILE); } catch {} });

test('registro, duplicado y login', async () => {
  const r = await api('/auth/register', { method: 'POST', body: { name: 'Ana', email: 'ana@correo.com', password: 'secreto1' } });
  assert.equal(r.s, 201); tok = r.j.token;
  assert.equal((await api('/auth/register', { method: 'POST', body: { name: 'Ana', email: 'ana@correo.com', password: 'secreto1' } })).s, 409);
  assert.equal((await api('/auth/login', { method: 'POST', body: { email: 'ana@correo.com', password: 'mala' } })).s, 401);
  assert.equal((await api('/auth/login', { method: 'POST', body: { email: 'ANA@correo.com', password: 'secreto1' } })).s, 200);
  assert.equal((await api('/auth/register', { method: 'POST', body: { name: 'X', email: 'no-es-correo', password: 'secreto1' } })).s, 400);
});
test('rutas y estado', async () => {
  assert.ok((await api('/routes?q=cue merlo')).j.length > 0);
  assert.equal((await api('/routes/4')).s, 200);
  assert.equal((await api('/routes/999')).s, 404);
  const s = (await api('/routes/4/status')).j;
  for (const k of ['arr', 'occ', 'seats', 'lvl']) assert.ok(k in s);
});
test('telemetría exige clave y valida rangos', async () => {
  assert.equal((await api('/units/4/telemetry', { method: 'POST', body: { occ: 50 } })).s, 401);
  const h = { 'x-operator-key': 'dev-operator-key' };
  assert.equal((await api('/units/4/telemetry', { method: 'POST', body: { occ: 150 }, headers: h })).s, 400);
  const r = await api('/units/4/telemetry', { method: 'POST', body: { occ: 88, lat: 19.05, lng: -98.2 }, headers: h });
  assert.equal(r.j.real, true); assert.equal(r.j.lvl, 'Alto');
});
test('pagos: tarifas de Puebla por tipo de unidad, saldo y gratuitos', async () => {
  const pay = (b, t = tok) => api('/payments', { method: 'POST', body: { route: 4, ...b } }, t);
  assert.equal((await api('/payments', { method: 'POST', body: { route: 4, kind: 'combi', fare: 'gen', method: 'saldo' } })).s, 401);
  assert.equal((await pay({ kind: 'autobus', fare: 'gen', method: 'saldo', amount: 8 })).s, 409);
  assert.equal((await pay({ kind: 'autobus', fare: 'gen', method: 'saldo', amount: 8.5 })).j.wallet, 41.5);
  assert.equal((await pay({ kind: 'combi', fare: 'gen', method: 'saldo', amount: 8 })).j.wallet, 33.5);
  assert.equal((await pay({ kind: 'autobus', fare: 'est', method: 'saldo' })).s, 403); // estudiante sin verificar
  assert.equal((await pay({ kind: 'autobus', fare: 'nino', method: 'saldo' })).j.wallet, 33.5); // gratis: no descuenta
  assert.equal((await pay({ kind: 'autobus', fare: 'gen', method: 'gratis' })).s, 400);
  for (let i = 0; i < 3; i++) assert.equal((await pay({ kind: 'autobus', fare: 'gen', method: 'saldo' })).s, 201); // 25, 16.5, 8
  assert.equal((await pay({ kind: 'autobus', fare: 'gen', method: 'saldo' })).s, 402);
  assert.equal((await api('/wallet/topup', { method: 'POST', body: { amount: 7 } }, tok)).s, 400);
  assert.equal((await api('/wallet/topup', { method: 'POST', body: { amount: 50 } }, tok)).j.wallet, 58);
  assert.equal((await api('/me/trips', {}, tok)).j.length, 6);
});
test('verificación de tarifa preferencial', async () => {
  const v = { kind: 'est', name: 'Ana Pérez', org: 'BUAP', folio: 'A1234567', until: '2099-07-31', hasDoc: true };
  const post = b => api('/verifications', { method: 'POST', body: b }, tok), op = { 'x-operator-key': 'dev-operator-key' };
  assert.equal((await post({ ...v, hasDoc: false })).s, 400);
  assert.equal((await post({ ...v, until: '2020-01-01' })).s, 400);
  const c = await post(v); assert.equal(c.s, 201);
  const est = () => api('/payments', { method: 'POST', body: { route: 4, kind: 'autobus', fare: 'est', method: 'saldo' } }, tok);
  assert.equal((await est()).s, 403); // en revisión
  assert.equal((await api('/verifications/' + c.j.id, { method: 'PATCH', body: { status: 'ok' } })).s, 401);
  assert.equal((await api('/verifications/' + c.j.id, { method: 'PATCH', body: { status: 'ok' }, headers: op })).j.status, 'ok');
  const p = await est(); assert.equal(p.s, 201); assert.equal(p.j.wallet, 52);
  assert.equal((await api('/me/verifications', {}, tok)).j[0].folio, '••••567');
});
test('ingresos: Cubi Plus, patrocinios, flotas y tablero', async () => {
  const op = { 'x-operator-key': 'dev-operator-key' };
  assert.equal((await api('/me/plus', { method: 'POST', body: { plan: 'weekly' } }, tok)).s, 400);
  const p = await api('/me/plus', { method: 'POST', body: { plan: 'month' } }, tok);
  assert.equal(p.s, 201); assert.equal(p.j.trial, true);
  assert.equal((await api('/me/plus', { method: 'POST', body: { plan: 'year' } }, tok)).s, 409);
  assert.equal((await api('/me', {}, tok)).j.plus.plan, 'month');
  assert.equal((await api('/sponsors', { method: 'POST', body: { name: 'Cafe', text: 'Hola', url: 'javascript:x' }, headers: op })).s, 400);
  const sp = await api('/sponsors', { method: 'POST', body: { name: 'Café Centro', text: '2x1 con tu boleto', url: 'https://example.com', monthly: 1200 }, headers: op });
  assert.equal(sp.s, 201);
  const pub = (await api('/sponsors')).j; assert.equal(pub.length, 1); assert.equal(pub[0].monthly, undefined);
  assert.equal((await api('/sponsors/' + sp.j.id + '/event', { method: 'POST', body: { type: 'view' } })).s, 200);
  assert.equal((await api('/sponsors/' + sp.j.id + '/event', { method: 'POST', body: { type: 'hack' } })).s, 404);
  assert.equal((await api('/fleets', { method: 'POST', body: { name: 'Ruta 4 S.A.', units: 10, pricePerUnit: 149 }, headers: op })).s, 201);
  assert.equal((await api('/admin/revenue')).s, 401);
  const r = (await api('/admin/revenue', { headers: op })).j;
  assert.equal(r.fleet.mrr, 1490); assert.equal(r.sponsors.mrr, 1200); assert.equal(r.sponsors.views, 1); assert.equal(r.plus.trials, 1);
  assert.equal(r.totalMonthly, Math.round((r.fleet.mrr + r.plus.mrr + r.sponsors.mrr + r.payments.fees) * 100) / 100);
  assert.equal((await api('/me/plus', { method: 'DELETE' }, tok)).s, 200);
});
test('valor de Plus: plan estudiante, referidos y beneficios', async () => {
  const op = { 'x-operator-key': 'dev-operator-key' };
  const reg = async n => (await api('/auth/register', { method: 'POST', body: { name: n, email: n + '@correo.com', password: 'secreto1' } })).j.token;
  const b = await reg('beto'), c = await reg('carla');
  assert.equal((await api('/me/plus', { method: 'POST', body: { plan: 'student' } }, b)).s, 403);
  const code = (await api('/me', {}, tok)).j.ref; assert.match(code, /^CUBI-[0-9A-F]{6}$/);
  assert.equal((await api('/referrals/redeem', { method: 'POST', body: { code } }, tok)).s, 404);
  assert.equal((await api('/referrals/redeem', { method: 'POST', body: { code: 'CUBI-000000' } }, b)).s, 404);
  const r = await api('/referrals/redeem', { method: 'POST', body: { code } }, b);
  assert.equal(r.s, 200); assert.ok(r.j.plus);
  assert.equal((await api('/referrals/redeem', { method: 'POST', body: { code } }, b)).s, 409);
  const sp = await api('/sponsors', { method: 'POST', body: { name: 'Café Sur', text: 'Hola', url: 'https://example.com', perk: { text: '2x1 en café', code: 'CUBI-CAFE' } }, headers: op });
  const pub = (await api('/sponsors')).j.find(x => x.id === sp.j.id);
  assert.equal(pub.perk.text, '2x1 en café'); assert.equal(pub.perk.code, undefined);
  assert.equal((await api('/perks', {}, c)).s, 403);
  assert.equal((await api('/perks', {}, b)).j[0].code, 'CUBI-CAFE');
  assert.equal((await api('/perks/' + sp.j.id + '/redeem', { method: 'POST', body: {} }, b)).s, 200);
  const rv = (await api('/admin/revenue', { headers: op })).j;
  assert.equal(rv.sponsors.redeemed, 1);
});
test('Pase Cubi: compra, uso con bono Plus y comisión', async () => {
  const op = { 'x-operator-key': 'dev-operator-key' };
  const reg = async n => (await api('/auth/register', { method: 'POST', body: { name: n, email: n + '@correo.com', password: 'secreto1' } })).j.token;
  const d = await reg('dani'), e = await reg('eli');
  assert.equal((await api('/passes', { method: 'POST', body: { pack: 'p20', method: 'saldo' } }, d)).s, 402);
  assert.equal((await api('/wallet/topup', { method: 'POST', body: { amount: 200 } }, d)).j.wallet, 250);
  const b = await api('/passes', { method: 'POST', body: { pack: 'p20', method: 'saldo' } }, d);
  assert.equal(b.s, 201); assert.equal(b.j.total, 20); assert.equal(b.j.wallet, 80);
  assert.equal((await api('/passes', { method: 'POST', body: { pack: 'p20', method: 'card' } }, d)).s, 409);
  const p = await api('/payments', { method: 'POST', body: { route: 4, kind: 'autobus', fare: 'gen', method: 'pase' } }, d);
  assert.equal(p.s, 201); assert.equal(p.j.wallet, 80);
  assert.equal((await api('/me/pass', {}, d)).j.left, 19);
  assert.equal((await api('/payments', { method: 'POST', body: { route: 4, kind: 'autobus', fare: 'gen', method: 'pase' } }, e)).s, 402);
  await api('/me/plus', { method: 'POST', body: { plan: 'month' } }, e);
  assert.equal((await api('/passes', { method: 'POST', body: { pack: 'p40', method: 'card' } }, e)).j.total, 42);
  const rv = (await api('/admin/revenue', { headers: op })).j;
  assert.equal(rv.passes.sold, 2); assert.equal(rv.passes.volume, 510); assert.equal(rv.passes.fees, 10.2);
});
test('paradas cercanas y sugerencias de la comunidad', async () => {
  const op = { 'x-operator-key': 'dev-operator-key' }, body = { name: '11 Sur y 31 Poniente', lat: 19.04, lng: -98.2 };
  assert.equal((await api('/stops')).s, 400);
  assert.equal((await api('/stops?lat=19.04&lng=-98.2')).j.length, 0);
  assert.equal((await api('/stops/suggest', { method: 'POST', body })).s, 401);
  assert.equal((await api('/stops/suggest', { method: 'POST', body: { ...body, name: 'x' } }, tok)).s, 400);
  const s = await api('/stops/suggest', { method: 'POST', body }, tok); assert.equal(s.s, 201);
  assert.equal((await api('/stops/suggestions')).s, 401);
  assert.equal((await api('/stops/suggestions/' + s.j.id, { method: 'PATCH', body: { status: 'ok', routes: ['4'] }, headers: op })).j.status, 'ok');
  const near = (await api('/stops?lat=19.0401&lng=-98.2001&r=500')).j;
  assert.equal(near.length, 1); assert.equal(near[0].n, '11 Sur y 31 Poniente'); assert.ok(near[0].d < 50);
});
test('RUTA: tarifas propias y recorrido con coordenadas', async () => {
  const pay = (b, t = tok) => api('/payments', { method: 'POST', body: { route: 4, kind: 'ruta', ...b } }, t);
  assert.equal((await pay({ fare: 'gen', method: 'card', amount: 8.5 })).s, 409);
  assert.equal((await pay({ fare: 'gen', method: 'card', amount: 7.5 })).s, 201);
  assert.equal((await pay({ fare: 'est', method: 'card' })).s, 400); // RUTA no tiene tarifa de estudiante
  assert.equal((await pay({ fare: 'nino', method: 'gratis' })).s, 400);
  assert.equal((await api('/routes/4/geo')).j[0].length, 2);
  assert.equal((await api('/routes/5/geo')).s, 404);
});
test('reportes: crear y listar solo para operador', async () => {
  assert.equal((await api('/reports', { method: 'POST', body: { route: 4, reason: 'Cobro incorrecto' } }, tok)).s, 201);
  assert.equal((await api('/reports')).s, 401);
  assert.equal((await api('/reports', { headers: { 'x-operator-key': 'dev-operator-key' } })).j.length, 1);
});
test('cambiar contraseña invalida la sesión anterior; eliminar cuenta borra todo', async () => {
  assert.equal((await api('/auth/password', { method: 'POST', body: { current: 'x', next: 'nueva123' } }, tok)).s, 403);
  const c = await api('/auth/password', { method: 'POST', body: { current: 'secreto1', next: 'nueva123' } }, tok);
  assert.equal(c.s, 200); assert.equal((await api('/me', {}, tok)).s, 401);
  const nt = c.j.token; assert.equal((await api('/me', {}, nt)).s, 200);
  assert.equal((await api('/me', { method: 'DELETE' }, nt)).s, 200);
  assert.equal((await api('/auth/login', { method: 'POST', body: { email: 'ana@correo.com', password: 'nueva123' } })).s, 401);
});
