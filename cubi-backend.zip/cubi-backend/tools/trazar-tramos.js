#!/usr/bin/env node
'use strict';
// Traza sobre OpenStreetMap los TRAMOS CON MODIFICACIÓN DE ITINERARIO del directorio (data/rutas.json).
// IMPORTANTE: el PDF del que salen esos datos NO trae el recorrido completo de cada ruta, solo desvíos
// parciales sobre tres bulevares. Este script dibuja esos desvíos, no la ruta entera.
//
// Uso:
//   node tools/trazar-tramos.js                       descarga las calles de OSM (Overpass) en 9 cuadrantes y las guarda en tools/.cache-osm
//   node tools/trazar-tramos.js --osm-file=osm.json   usa un archivo Overpass ya descargado (out geom)
//   Opciones: --incluir-bajas  también publica los tramos de confianza baja
// Salida: data/rutas_geo.json  { "<id de ruta>": [ { n, conf, pts: [[lat,lng],...] } ] }  y  data/rutas_geo_reporte.csv
const fs = require('fs'), path = require('path');

const BBOX = [18.90, -98.40, 19.20, -98.00]; // sur, oeste, norte, este
const STOPW = new Set(['de', 'del', 'la', 'las', 'los', 'el', 'y']);
const ABBR = [[/\bav(?=\s|$)/g, 'avenida'], [/\bavda(?=\s|$)/g, 'avenida'], [/\bblvd(?=\s|$)/g, 'boulevard'], [/\bbvd(?=\s|$)/g, 'boulevard'], [/\bote(?=\s|$)/g, 'oriente'], [/\bpte(?=\s|$)/g, 'poniente'], [/\bnte(?=\s|$)/g, 'norte'], [/\bpriv(?=\s|$)/g, 'privada'], [/\bcalz(?=\s|$)/g, 'calzada'], [/\bdiag(?=\s|$)/g, 'diagonal'], [/\bcarr(?=\s|$)/g, 'carretera']];

function key(s) { // nombre normalizado para comparar calles (sin acentos, abreviaturas expandidas, sin artículos)
  let t = String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[“”"'.,()]/g, ' ');
  for (const [r, v] of ABBR) t = t.replace(r, v);
  return t.split(/\s+/).filter(w => w && !STOPW.has(w)).join(' ');
}
function variants(name) { // "Calzada Ignacio Zaragoza o 2 Norte" -> varias calles posibles; "2 Norte" también como "Calle 2 Norte"
  const out = new Set();
  for (const part of String(name || '').split(/\s+o\s+/i)) {
    const k = key(part); if (!k) continue;
    out.add(k); if (/^\d/.test(k)) { out.add('calle ' + k); out.add('avenida ' + k); }
  }
  return [...out];
}
const rad = x => x * Math.PI / 180;
const dist = (a, b) => { const dl = rad(b[0] - a[0]), dn = rad(b[1] - a[1]), x = Math.sin(dl / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dn / 2) ** 2; return 2 * 6371000 * Math.asin(Math.sqrt(x)); };

// ---- índice de calles de OSM ----
function buildIndex(elements) {
  const nodeLL = new Map(), byKey = new Map();
  for (const w of elements) {
    if (w.type !== 'way' || !w.nodes || !w.geometry) continue;
    w.nodes.forEach((id, i) => nodeLL.set(id, [w.geometry[i].lat, w.geometry[i].lon]));
    for (const nm of [w.tags && w.tags.name, w.tags && w.tags.alt_name]) { const k = key(nm); if (!k) continue; if (!byKey.has(k)) byKey.set(k, []); byKey.get(k).push(w); }
  }
  return { nodeLL, byKey, cache: new Map() };
}
function street(index, name) { // calle = unión de todas las vías con ese nombre (o variantes); devuelve null si no existe
  const ck = 'st:' + name; if (index.cache.has(ck)) return index.cache.get(ck);
  const ways = new Set(); for (const v of variants(name)) for (const w of index.byKey.get(v) || []) ways.add(w);
  let res = null;
  if (ways.size) {
    const adj = new Map(), add = (a, b) => { const d = dist(index.nodeLL.get(a), index.nodeLL.get(b)); if (!adj.has(a)) adj.set(a, []); adj.get(a).push({ to: b, d }); };
    for (const w of ways) for (let i = 0; i < w.nodes.length - 1; i++) { add(w.nodes[i], w.nodes[i + 1]); add(w.nodes[i + 1], w.nodes[i]); }
    res = { name, adj, nodes: new Set(adj.keys()) };
  }
  index.cache.set(ck, res); return res;
}
function inter(index, A, B) { // cruces entre dos calles: nodos compartidos o, si no hay, nodos a menos de 30 m
  const shared = [...A.nodes].filter(n => B.nodes.has(n)).map(n => ({ a: n, b: n }));
  if (shared.length) return shared;
  const cell = 0.0003, hash = new Map(), c = ll => Math.floor(ll[0] / cell) + ':' + Math.floor(ll[1] / cell);
  for (const n of B.nodes) { const k = c(index.nodeLL.get(n)); if (!hash.has(k)) hash.set(k, []); hash.get(k).push(n); }
  const out = [];
  for (const a of A.nodes) {
    const la = index.nodeLL.get(a), [i, j] = [Math.floor(la[0] / cell), Math.floor(la[1] / cell)];
    for (let di = -1; di <= 1; di++) for (let dj = -1; dj <= 1; dj++) for (const b of hash.get((i + di) + ':' + (j + dj)) || []) if (dist(la, index.nodeLL.get(b)) <= 30) out.push({ a, b });
  }
  return out.slice(0, 12);
}
function sp(index, S, src) { // distancias mínimas desde src a lo largo de la misma calle (Dijkstra sencillo)
  const ck = 'sp:' + S.name + ':' + src; if (index.cache.has(ck)) return index.cache.get(ck);
  const dist_ = new Map([[src, 0]]), prev = new Map(), done = new Set(), q = [[0, src]];
  while (q.length) {
    q.sort((x, y) => x[0] - y[0]); const [d, u] = q.shift(); if (done.has(u)) continue; done.add(u);
    for (const e of S.adj.get(u) || []) { const nd = d + e.d; if (nd < (dist_.has(e.to) ? dist_.get(e.to) : Infinity)) { dist_.set(e.to, nd); prev.set(e.to, u); q.push([nd, e.to]); } }
  }
  const r = { dist: dist_, prev }; index.cache.set(ck, r); return r;
}
function pathNodes(r, src, dst) { const out = [dst]; let u = dst; while (u !== src) { u = r.prev.get(u); if (u === undefined) return null; out.push(u); } return out.reverse(); }
function simplify(pts, tol = 4) { // Douglas-Peucker con tolerancia en metros
  if (pts.length < 3) return pts;
  const d2 = (p, a, b) => { const k = Math.cos(rad(a[0])), ax = a[1] * k * 111320, ay = a[0] * 110540, bx = b[1] * k * 111320, by = b[0] * 110540, px = p[1] * k * 111320, py = p[0] * 110540, dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; const t = l ? Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l)) : 0; return Math.hypot(px - ax - t * dx, py - ay - t * dy); };
  let mx = 0, mi = 0; for (let i = 1; i < pts.length - 1; i++) { const d = d2(pts[i], pts[0], pts[pts.length - 1]); if (d > mx) { mx = d; mi = i; } }
  if (mx <= tol) return [pts[0], pts[pts.length - 1]];
  return simplify(pts.slice(0, mi + 1), tol).slice(0, -1).concat(simplify(pts.slice(mi), tol));
}

// ---- un tramo: calle principal s, empieza en a, giros p, termina en z ----
function trazarTramo(t, index) {
  if ((t.p || []).some(g => g[0] === 'U' || g[0] === 'E')) return { ok: false, reason: 'incluye vuelta en U o "Entra" (no soportado)' };
  const names = [t.a, ...(t.p || []).map(g => g[1])].filter(Boolean).filter((n, i, a) => i === 0 || key(n) !== key(a[i - 1]));
  if (!t.s || !names.length || !t.z) return { ok: false, reason: 'faltan datos del tramo' };
  const S = names.map(n => street(index, n)), main = street(index, t.s), zs = variants(t.z).length ? String(t.z).split(/\s+o\s+/i).map(n => street(index, n)).filter(Boolean) : [];
  const miss = [!main && t.s, ...S.map((s, i) => !s && names[i]), !zs.length && t.z].filter(Boolean);
  if (miss.length) return { ok: false, reason: 'calle no encontrada en OSM: ' + [...new Set(miss)].join(' | ') };
  const LIM_LEG = 8000, LIM_TOT = 30000;
  let states = inter(index, main, S[0]).map(c => ({ node: c.b, cost: 0, prev: null, street: S[0], enter: c.b })), maxCand = states.length;
  if (!states.length) return { ok: false, reason: 'la calle principal no cruza con la primera calle del desvío' };
  for (let i = 0; i < S.length; i++) {
    const last = i === S.length - 1;
    const trans = last ? zs.flatMap(z => inter(index, S[i], z)) : inter(index, S[i], S[i + 1]);
    if (!trans.length) return { ok: false, reason: 'no hay cruce entre ' + names[i] + ' y ' + (last ? t.z : names[i + 1]) };
    maxCand = Math.max(maxCand, trans.length);
    const next = [];
    for (const c of trans) {
      let best = null;
      for (const st of states) { const r = sp(index, S[i], st.node), d = r.dist.get(c.a); if (d !== undefined && d <= LIM_LEG && st.cost + d <= LIM_TOT && (!best || st.cost + d < best.cost)) best = { node: c.b, cost: st.cost + d, prev: st, street: S[i], from: st.node, to: c.a }; }
      if (best) next.push(best);
    }
    if (!next.length) return { ok: false, reason: 'tramo desconectado o demasiado largo en ' + names[i] };
    states = next;
  }
  const fin = states.reduce((a, b) => (a.cost <= b.cost ? a : b)), legs = [];
  for (let s = fin; s && s.prev; s = s.prev) legs.unshift(s);
  let ids = [legs[0].prev.enter ? legs[0].prev.enter : legs[0].from];
  const pts = [];
  for (const g of legs) { const r = sp(index, g.street, g.from), seg = pathNodes(r, g.from, g.to); if (!seg) return { ok: false, reason: 'no se pudo reconstruir el camino' }; seg.forEach(n => pts.push(index.nodeLL.get(n))); if (g.node !== g.to) pts.push(index.nodeLL.get(g.node)); }
  const out = simplify(pts.filter((p, i) => i === 0 || p[0] !== pts[i - 1][0] || p[1] !== pts[i - 1][1])).map(p => [+p[0].toFixed(5), +p[1].toFixed(5)]);
  return { ok: true, pts: out, meters: Math.round(fin.cost), conf: maxCand === 1 ? 'alta' : maxCand <= 3 ? 'media' : 'baja' };
}

// ---- descarga de OSM ----
async function overpass(q) { const r = await fetch('https://overpass-api.de/api/interpreter', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'data=' + encodeURIComponent(q) }); if (!r.ok) throw new Error('Overpass respondió ' + r.status); return r.json(); }
async function cargarOSM(opts) {
  if (opts.file) return JSON.parse(fs.readFileSync(opts.file, 'utf8')).elements;
  const dir = path.join(__dirname, '.cache-osm'); fs.mkdirSync(dir, { recursive: true });
  const [s, w, n, e] = BBOX, N = 3, els = new Map();
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
    const f = path.join(dir, `t${i}${j}.json`);
    if (!fs.existsSync(f)) {
      const bb = [s + (n - s) * i / N, w + (e - w) * j / N, s + (n - s) * (i + 1) / N, w + (e - w) * (j + 1) / N].map(x => x.toFixed(5)).join(',');
      for (let tryN = 1; ; tryN++) { try { fs.writeFileSync(f, JSON.stringify(await overpass(`[out:json][timeout:180];way["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|service|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link)$"]["name"](${bb});out geom;`))); break; } catch (err) { if (tryN >= 3) throw err; await new Promise(r => setTimeout(r, 8000)); } }
      console.log(`Cuadrante ${i * N + j + 1}/${N * N} descargado`); await new Promise(r => setTimeout(r, 2000));
    }
    for (const x of JSON.parse(fs.readFileSync(f, 'utf8')).elements) els.set(x.id, x);
  }
  return [...els.values()];
}

async function main() {
  const args = process.argv.slice(2), opts = { file: (args.find(a => a.startsWith('--osm-file=')) || '').slice(11), bajas: args.includes('--incluir-bajas') };
  const DATA = path.join(__dirname, '..', 'data'), rutas = JSON.parse(fs.readFileSync(path.join(DATA, 'rutas.json'), 'utf8'));
  console.log('Cargando calles de OpenStreetMap…'); const index = buildIndex(await cargarOSM(opts));
  const memo = new Map(), geo = {}, rep = [['ruta_id', 'ruta', 'tramo', 'resultado', 'confianza', 'metros', 'motivo']];
  let ok = 0, total = 0;
  for (const r of rutas) {
    const seen = new Set();
    r.t.forEach((t, ti) => {
      const sig = JSON.stringify([t.s, t.a, t.z, t.p]); if (seen.has(sig)) return; seen.add(sig); total++;
      if (!memo.has(sig)) memo.set(sig, trazarTramo(t, index));
      const x = memo.get(sig), pub = x.ok && (x.conf !== 'baja' || opts.bajas);
      rep.push([r.i, r.n, `${ti + 1}. ${t.s}${t.d ? ' (' + t.d + ')' : ''}`, pub ? 'trazado' : x.ok ? 'omitido (confianza baja)' : 'omitido', x.conf || '', x.meters || '', x.reason || '']);
      if (pub) { ok++; (geo[r.i] = geo[r.i] || []).push({ n: `${t.s}${t.d ? ' (' + t.d + ')' : ''}`, conf: x.conf, pts: x.pts }); }
    });
  }
  fs.writeFileSync(path.join(DATA, 'rutas_geo.json'), JSON.stringify(geo));
  fs.writeFileSync(path.join(DATA, 'rutas_geo_reporte.csv'), rep.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n'));
  console.log(`Listo: ${ok} de ${total} tramos trazados en ${Object.keys(geo).length} rutas. Revisa data/rutas_geo_reporte.csv antes de usarlos.`);
}
module.exports = { key, variants, buildIndex, trazarTramo, simplify };
if (require.main === module) main().catch(e => { console.error('Error:', e.message); process.exit(1); });
