#!/usr/bin/env node
'use strict';
// Convierte la plantilla llena (data/rutas_tipo_plantilla.csv) en data/rutas_tipo.json: { "<id>": "autobus" | "combi" }.
// En la columna "tipo" escribe: combi o autobus (se aceptan "autobús" y "camión"). Las filas vacías se ignoran.
//   node tools/importar-tipos.js [archivo.csv]
const fs = require('fs'), path = require('path');
const src = process.argv[2] || path.join(__dirname, '..', 'data', 'rutas_tipo_plantilla.csv'), out = path.join(__dirname, '..', 'data', 'rutas_tipo.json');
const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
const rows = fs.readFileSync(src, 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/).filter(Boolean).map(l => { const o = []; let cur = '', q = false; for (const c of l) { if (c === '"') q = !q; else if ((c === ',' || c === ';') && !q) { o.push(cur); cur = ''; } else cur += c; } o.push(cur); return o; });
const head = rows.shift().map(norm), iId = head.indexOf('id'), iTipo = head.indexOf('tipo');
if (iId < 0 || iTipo < 0) { console.error('El archivo necesita las columnas "id" y "tipo".'); process.exit(1); }
const map = {}, bad = [];
for (const r of rows) {
  const t = norm(r[iTipo]); if (!t) continue;
  const k = /micro/.test(t) ? null : /combi|van/.test(t) ? 'combi' : /autobus|camion/.test(t) ? 'autobus' : null; // microbús no es ninguno de los dos: se reporta
  if (k) map[r[iId]] = k; else bad.push(`${r[iId]} (${r[iTipo]})`);
}
fs.writeFileSync(out, JSON.stringify(map));
console.log(`Listo: ${Object.keys(map).length} rutas con tipo (${Object.values(map).filter(v => v === 'combi').length} combis, ${Object.values(map).filter(v => v === 'autobus').length} autobuses).` + (bad.length ? ` No reconocí: ${bad.join(', ')}.` : ''));
