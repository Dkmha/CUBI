const test = require('node:test'), assert = require('node:assert/strict');
const { key, variants, buildIndex, trazarTramo } = require('../tools/trazar-tramos');

// Rejilla sintética: lat = 19.000 + fila*0.001, lng = -98.200 + columna*0.001. Los cruces comparten nodos.
const ids = new Map(); const nid = (r, c) => { const k = r + ',' + c; if (!ids.has(k)) ids.set(k, ids.size + 1); return ids.get(k); };
const way = (name, cells, id) => ({ type: 'way', id, tags: { name, highway: 'residential' }, nodes: cells.map(([r, c]) => nid(r, c)), geometry: cells.map(([r, c]) => ({ lat: 19 + r * 0.001, lon: -98.2 + c * 0.001 })) });
const row = (r, c0, c1) => Array.from({ length: c1 - c0 + 1 }, (_, i) => [r, c0 + i]), col = (c, r0, r1) => Array.from({ length: r1 - r0 + 1 }, (_, i) => [r0 + i, c]);
const osm = [
  way('Boulevard Héroes del 5 de Mayo', col(0, 0, 8), 1), way('Av. 14 Ote.', row(3, 0, 8), 2), way('Calle 14 Norte', col(2, 0, 8), 3),
  way('Avenida 20 Oriente', row(5, 0, 8), 4), way('Boulevard Xonaca', col(5, 0, 8), 5), way('Calle Aislada', row(7, 7, 8), 6)
];
const idx = buildIndex(osm), ll = (r, c) => [+(19 + r * 0.001).toFixed(5), +(-98.2 + c * 0.001).toFixed(5)];
const tramo = { s: 'Boulevard Héroes del 5 de Mayo', a: 'Avenida 14 Oriente', z: 'Boulevard Xonaca', p: [['D', 'Calle 14 Norte'], ['D', 'Avenida 20 Oriente']] };

test('normaliza nombres y variantes de calles', () => {
  assert.equal(key('Av. 14 Ote.'), key('Avenida 14 Oriente'));
  assert.equal(key('Boulevard Héroes del 5 de Mayo'), key('Blvd Heroes 5 de Mayo'));
  assert.ok(variants('Calzada Ignacio Zaragoza o 2 Norte').includes('calle 2 norte'));
});
test('traza un desvío de punta a punta pasando por los cruces correctos', () => {
  const r = trazarTramo(tramo, idx);
  assert.equal(r.ok, true); assert.equal(r.conf, 'alta');
  assert.deepEqual(r.pts[0], ll(3, 0)); assert.deepEqual(r.pts[r.pts.length - 1], ll(5, 5));
  assert.ok(r.pts.some(p => p[0] === ll(3, 2)[0] && p[1] === ll(3, 2)[1]), 'pasa por Av. 14 Oriente y Calle 14 Norte');
  assert.ok(r.pts.some(p => p[0] === ll(5, 2)[0] && p[1] === ll(5, 2)[1]), 'pasa por Calle 14 Norte y Av. 20 Oriente');
  assert.ok(Math.abs(r.meters - 748) < 6, 'longitud: 2 cuadras al este, 2 al norte y 3 al este (unos 750 m), no ' + r.meters);
});
test('rechaza lo que no puede resolver y lo explica', () => {
  assert.match(trazarTramo({ ...tramo, a: 'Avenida Inexistente' }, idx).reason, /no encontrada/);
  assert.match(trazarTramo({ ...tramo, p: [['U', 'Calle 14 Norte']] }, idx).reason, /vuelta en U/);
  assert.match(trazarTramo({ ...tramo, z: 'Calle Aislada' }, idx).reason, /no hay cruce|desconectado/);
});
